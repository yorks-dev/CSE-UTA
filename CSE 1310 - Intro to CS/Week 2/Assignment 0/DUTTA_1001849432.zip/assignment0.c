#include <stdio.h>
#define PI 3.14159
int main(void) {
    float r = 2.1;
    float circumference = 2 * PI * r;
    printf("%f\n", r);
    return 0;
}